import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bills-utilities',
  templateUrl: './bills-utilities.component.html',
  styleUrls: ['./bills-utilities.component.scss']
})
export class BillsUtilitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
