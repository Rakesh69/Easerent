import { ProductCategoryFilterPipe } from './product-category-filter.pipe';

describe('ProductCategoryFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ProductCategoryFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
