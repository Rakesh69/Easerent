import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-document',
  templateUrl: './list-document.component.html',
  styleUrls: ['./list-document.component.scss']
})
export class ListDocumentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
