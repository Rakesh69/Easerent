import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notification-setting',
  templateUrl: './notification-setting.component.html',
  styleUrls: ['./notification-setting.component.scss']
})
export class NotificationSettingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
