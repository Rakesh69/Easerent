import { environment } from '../../environments/environment';

export const urlConstant = {

};
