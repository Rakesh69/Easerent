export const messageConstant = {
    Common: {
        Invalid: 'The User Name or Password provided is incorrect',   
        CreateSucess:'Record created successfully.',
        UpdateSucess:'Record updated successfully.',
        DeleteSucess:'Record deleted successfully.',
        Required: 'required',
        RecordNotFound: 'Record Detail Not Exist',
        DuplicateRecord:'Duplicate record found.',
        UnAuthorized:'UnAuthrized User',
    }
}
